# Open Flag — Python SDK

***Software development kit*** da plataforma **OpenFlag** para a linguagem de programação Python. Permite gerenciar feature flags, incluindo criação, edição, remoção, toggle e histórico de uso (timestamps), a nível de código.


## 🚀 Quick Start

### **Instalação**

```bash
cd dist/
pip install openflag-X.Y.Z.tar.gz
```

### **Exemplo de uso**

```python
>>> from openflag import OpenFlag

>>> conn = OpenFlag()
>>> conn.list()
[]

>>> conn.create("Flag", True, "This is an example.")
>>> conn.list()
["Flag"]

>>> conn.check("Flag")
{"name": "Flag", "value": True, "description": "This is an example.", "usage_log": [1000.0]}
```

### **Execução dos testes**

```bash
pip install -r tests/requirements.txt
pytest tests/
```

## 📁 Estrutura do projeto

```
sdk/
│── dist/            # Pacote instalável
│── src/             # Código-fonte
│── tests/           # Testes de unidade (pytest)
│── LICENSE          # Licença de uso (MIT)
│── pyproject.toml   # Configurações do projeto
│── README.md        # Esta documentação
```

## ⚙️ API Reference
    class OpenFlag()
     |  OpenFlag(host: str = 'localhost', port: int = 8000)
     |
     |  SDK for the OpenFlag flag management application.
     |
     |  ----------------------------------------------------------------------
     |
     |  check(self, name: str)
     |      Returns the current value of the given flag.
     |
     |      - name (str): The name of the flag to be checked
     |
     |      Returns:
     |      (bool): The value of the flag
     |      -1 (int): Flag not found
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------
     |
     |  create(self, name: str, value: bool, description: str)
     |      Creates a new flag.
     |
     |      - name (str): The name of the flag
     |      - value (bool): The initial value of the flag
     |      - description (str): The description of the flag
     |
     |      Returns:
     |      0 (int): Success
     |      -2 (int): Flag already exists
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------
     |
     |  list(self)
     |      Returns a list of all flags stored in the system.
     |
     |      Returns:
     |      list(str): List with names of stored flags
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------
     |
     |  remove(self, name: str)
     |      Excludes the given flag.
     |
     |      - name (str): The name of the flag to be excluded
     |
     |      Returns:
     |      0 (int): Success
     |      -1 (int): Flag not found
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------
     |
     |  toggle(self, name: str)
     |      Toggles the value (on/off) of the given flag.
     |
     |      - name (str): The name of the flag to be toggled
     |
     |      Returns:
     |      0 (int): Success
     |      -1 (int): Flag not found
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------
     |
     |  update(self, name: str, new_name: str, new_description: str)
     |      Updates the name and/or description of the given flag.
     |
     |      - name (str): The name of the flag to be modified
     |      - new_name (str): The new desired name
     |      - new_description (str): The new desired description
     |
     |      Returns:
     |      0 (int): Success
     |      -1 (int): Flag not found
     |      -3 (int): Unknown error
     |
     |  ----------------------------------------------------------------------