# Open Flag — Python SDK

***Software development kit*** da plataforma **OpenFlag** para a linguagem de programação Python. Permite gerenciar feature flags, incluindo criação, edição, remoção, toggle e histórico de uso (timestamps), a nível de código.


## 🚀 Instalação

```bash

```

Exemplo de uso:

```python

```

Execução dos testes:

```bash
pytest tests/
```

## 📁 Estrutura do projeto

```
sdk/
│── dist/            # Pacote instalável
│── src/             # Código-fonte
│── tests/           # Testes de unidade (pytest)
│── LICENSE          # Licença de uso (MIT)
│── pyproject.toml   # Configurações do projeto
│── README.md        # Esta documentação
```